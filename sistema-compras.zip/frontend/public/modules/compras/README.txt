Vista compras
