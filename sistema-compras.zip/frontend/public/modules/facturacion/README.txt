Vista facturacion
