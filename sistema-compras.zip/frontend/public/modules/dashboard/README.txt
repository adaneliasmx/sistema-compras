Vista dashboard
