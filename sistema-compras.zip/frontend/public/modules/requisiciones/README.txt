Vista requisiciones
