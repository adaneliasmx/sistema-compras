Vista seguimiento
