Vista inventarios
