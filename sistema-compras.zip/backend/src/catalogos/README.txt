Módulo catalogos
