Módulo admin
