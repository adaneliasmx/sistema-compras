Módulo auth
