Módulo inventarios
