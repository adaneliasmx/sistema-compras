Módulo cotizaciones
