Módulo users
